# Run as administrator. Removes only the exact experimental override created for this device.
# A normal Windows restart is required afterward. This does not flash firmware.
$ErrorActionPreference = 'Stop'
$taskKeyPath = 'SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0001'
$taskExpected = [byte[]]::new(14)
[Buffer]::BlockCopy([BitConverter]::GetBytes([int]0x57C36),0,$taskExpected,5,4)
$taskExpected[9] = 4
[Buffer]::BlockCopy([BitConverter]::GetBytes([int]225000),0,$taskExpected,10,4)
$taskKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($taskKeyPath,$true)
if (-not $taskKey) {throw 'NVIDIA registry key unavailable'}
try {
 if ($taskKey.GetValue('MatchingDeviceId') -ne 'pci\ven_10de&dev_2c58&subsys_3e481043') {throw 'Device identity differs; stopped'}
 $value=$taskKey.GetValue('romOverride00',$null)
 if ($null -ne $value) {
  if ($value -isnot [byte[]] -or [Convert]::ToHexString($value) -ne [Convert]::ToHexString($taskExpected)) {throw 'Value is not the exact override created by this task; stopped'}
  $taskKey.DeleteValue('romOverride00',$false)
  $taskKey.Flush()
  if ($null -ne $taskKey.GetValue('romOverride00',$null)) {throw 'Removal readback failed'}
 }
 [ordered]@{Time=(Get-Date).ToString('o');OverrideRemoved=$true;RestartRequired=$true;FirmwareFlashed=$false;Note='Do not run GPU loads until a normal restart and readback confirm stock 175 W'} | ConvertTo-Json | Tee-Object -FilePath (Join-Path $PSScriptRoot 'restore-stock-max-result.json')
} finally {$taskKey.Dispose()}
